package com.sahana.services;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/hello")
public class Hello {
 
	@GET
	@Path("/get")
	public String getMsg() {
 
		String output = "Jersey say : ";
 
		return output;
 
	}
 
}
