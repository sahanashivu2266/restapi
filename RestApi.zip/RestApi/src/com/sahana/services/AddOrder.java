package com.sahana.services;



import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class AddOrder {
	/*static HashMap<Integer,String> order = new HashMap<Integer,String>();
	static int count = 0;*/
	
	static JSONArray order = new JSONArray();
	static JSONParser parser = new JSONParser();
	

	public static void addOrder(String res) throws Exception {
		JSONObject json = (JSONObject) parser.parse(res);
		order.put(json);
		
		System.out.println(json);
		
	}
	
	public static String getOrder(String id) {
		String output=" ";
		for(int i=0;i<order.length();i++) {
			org.json.JSONObject obj1 = order.getJSONObject(i);
			String id1=obj1.getString("id").toString();
			System.out.println(id1);
			if(id1.equals(id))
			output= obj1.toString();
			
		}
		return output;
	}
	
	public static String getAllOrder() {
		return order.toString();
	}
	
	public static void deleteOrder(String id) {
		for(int i=0;i<order.length();i++) {
			org.json.JSONObject obj1 = order.getJSONObject(i);
			String id1=obj1.getString("id").toString();
			System.out.println(id1);
			if(id1.equals(id)) {
				order.remove(i);
				System.out.println(order);
				return;
			}
		
		}
	}



	

	

}
