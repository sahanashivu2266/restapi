package com.sahana.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

@Path("/login")
public class Login {
	
	@POST
	@Path("/validate")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String validateData(String data) {
		JSONParser parser = new JSONParser();
		JSONObject json = new JSONObject();
		String name = " ";
		String password = " ";
		String email = " ";
		connect c = new connect();
		
		
		
		try {
			json = (JSONObject) parser.parse(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(data);
		name = (String)json.get("name");
		password = (String)json.get("password");
		if(c.validate(name, password))
		{	
			
			return ("success");
		}
		else {
			
			return ("user does not exists");
		}
		
	}
	
	
	
	@POST
	@Path("/register")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String registerUser(String input) {
		JSONParser parser = new JSONParser();
		JSONObject json = new JSONObject();
		String name = " ";
		String password = " ";
		String email = " ";
		
		
		String result=" ";
		connect c = new connect();
		
		
		
		try {
			json = (JSONObject) parser.parse(input);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(input);
		name = (String)json.get("name");
		password = (String)json.get("password");
		email = (String)json.get("email");
		result = c.register(name, password, email);
		return result;
		
	}

}
