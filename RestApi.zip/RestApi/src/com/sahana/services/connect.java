package com.sahana.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class connect {
	final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	final String DB_URL = "jdbc:mysql://localhost:3306/sahana";
	final String USER = "sahana";
	final String PASS = "Shash587#";
	Connection conn;
	boolean status = false;
	int i=0;

	public void connectDB() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		// Open a connection
		try {
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			if (conn == null) {
				System.out.println(" not connected");

			} else {
				System.out.println("connected");
			}
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			System.out.println("error");
		}

	}

	public boolean validate(String name, String password) {
		connectDB();
		try {
			PreparedStatement st = (PreparedStatement) conn
					.prepareStatement("select * from user where name=? AND password=?");
			st.setString(1, name);
			st.setString(2, password);

			ResultSet rs = st.executeQuery();

			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(status);
		return status;
	}
	
	
	
	
	public String register(String name, String password, String email) {
		connectDB();
		try {
			PreparedStatement st = (PreparedStatement) conn.prepareStatement("insert into user values(?,?,?)");
			st.setString(1, name);
			st.setString(2, password);
			st.setString(3, email);
			
			i = st.executeUpdate();
			
		}
		catch(SQLException e) {
			
		}
		
		if(i>0) {
			return("Registered successfully");
		}
		else {
			return("error in register");
		}
		
		
	}


}
