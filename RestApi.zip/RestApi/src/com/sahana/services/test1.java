package com.sahana.services;

public interface test1 {

}
