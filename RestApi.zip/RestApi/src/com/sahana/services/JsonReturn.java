package com.sahana.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.simple.JSONObject;


@Path("/orders")
public class JsonReturn {
	
	
	
	
	@GET
	@Path("/get/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public String display(@PathParam("id") String id){
	//	System.out.println(id);
		String output = AddOrder.getOrder(id);
		
		return output;
	/*	*/
		
	}
	
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public String getDisplay() {
		/*JSONObject obj = new JSONObject();
		obj.put("name", "sahana");
		obj.put("drink", "coffee");
		
		JSONArray a = new JSONArray();
		a.put(obj);
		
		return a;*/
		String a = new String();
		a = AddOrder.getAllOrder();
	//	System.out.println(a);
		return a;
		
	}
	
	
	
	@POST
	@Path("/post")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String consumePost(String obj1) {
		String res = obj1;
		//System.out.println(res);
		try {
			AddOrder.addOrder(res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	@DELETE
	@Path("/delete/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public void deleteOrder(@PathParam("id") String id) {
		AddOrder.deleteOrder(id);

		
	}
	
}
