package com.sahana.services;

import java.util.ArrayList;

class sample{
	private int a=9;
	
	
	
	
	
	public void msg() {
		
		ArrayList a = new ArrayList();
		System.out.println(a);
	}
}

public class testdelete{
	public static void main(String[] args) {
		sample t = new sample();
		try {
			t.msg();
		}
		finally{
			
		}
		
	}
	

}
